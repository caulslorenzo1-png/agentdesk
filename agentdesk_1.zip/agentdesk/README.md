# AgentDesk

An agent console: every request is reasoned about, planned, and risk-rated
*before* anything runs. Low-risk and draft actions (search, draft an email)
execute immediately; high-risk/irreversible ones (send an email, delete an
event) pause and wait for your explicit approval in the UI.

```
agentdesk/
├── backend/
│   ├── .env.example     ← copy to .env and fill in
│   ├── main.py           ← FastAPI server (/chat, /tools, /health)
│   ├── tools.py           ← tool registry (mock Gmail/Calendar — replace with real APIs)
│   ├── engine.py           ← reasoning/planning/execution/memory engine
│   ├── agent/__init__.py
│   └── requirements.txt
└── frontend/
    └── app/
        ├── page.tsx              ← chat UI + live agent-trace panel
        ├── layout.tsx
        ├── globals.css
        └── api/chat/route.ts     ← proxies to the backend
```

## 1. Backend

```bash
cd backend
python3 -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt
cp .env.example .env
# edit .env and set ANTHROPIC_API_KEY (or OPENAI_API_KEY)
uvicorn main:app --reload --port 8000
```

Check it's alive: `curl http://localhost:8000/health`

Without an API key set, the engine runs in demo mode and replies without
calling an LLM, so you can confirm the plumbing works first.

## 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:3000. It talks to the backend at
`http://localhost:8000` by default — set `BACKEND_URL` in a
`frontend/.env.local` file to point elsewhere.

## How a request flows

1. You send a message.
2. The engine (`engine.py`) asks the LLM to reason: a thought, a confidence
   score, a risk level, and a step-by-step plan against the registered tools.
3. If confidence is below the threshold (default 0.7) or any step is
   high-risk, the API returns `needs_confirmation: true` and the UI shows an
   Approve/Decline card instead of running anything.
4. On approval, `POST /chat` is called again with `confirm: true` and the
   cached plan, which executes it and returns the results.
5. Every turn is stored in memory (`MemoryStore`) so later requests can
   recall similar past interactions.

## Wiring up real tools

`backend/tools.py` currently uses in-memory mock data for inbox/calendar and
a stub for web search. Replace the function bodies (`search_inbox`,
`draft_email`, `send_email`, etc.) with real Gmail/Calendar/Slack API calls —
the `Tool` wrapper and risk levels stay the same, so nothing else needs to
change.

## What I changed from the original spec

The spec doc cut off mid-function inside `engine.py` and didn't include
`tools.py`, `main.py`, or any frontend files — those are new. I also fixed a
bug in `execute()`: it tried to rebuild `AgentThought` from a `"thought"` key
that `process()` never actually attached to the plan dict, which would have
crashed the first time a plan ran. It now passes the full reasoning result
through. I also dropped `langchain`, `qdrant-client`, `psycopg2-binary`, and
`sqlalchemy` from `requirements.txt` since nothing in the code used them —
add them back if you plan to swap in a real vector store or Postgres for
memory.
