"use client";

import { useState, useRef, useEffect } from "react";

type Thought = {
  thought: string;
  confidence: number;
  risk_level: "low" | "medium" | "high";
  uncertainty: string;
};

type PlanStep = { step?: number; action: string; params: Record<string, unknown>; risk?: string };
type Plan = { steps: PlanStep[]; expected_outcome: string; needs_confirmation: boolean };
type ActionResult = { tool: string; params: Record<string, unknown>; result: string; success: boolean };

type Message = {
  role: "user" | "agent";
  text: string;
  thought?: Thought;
  plan?: Plan;
  actions?: ActionResult[];
  pendingId?: string;
  awaitingConfirm?: boolean;
};

const riskColor: Record<string, string> = {
  low: "text-safe border-safe/40",
  medium: "text-signal border-signal/40",
  high: "text-danger border-danger/40",
};

export default function Page() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "agent",
      text: "AgentDesk is up. Ask for something — I'll show my reasoning and plan before I touch anything irreversible.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeTrace, setActiveTrace] = useState<Message | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function send(text: string) {
    if (!text.trim() || loading) return;
    setMessages((m) => [...m, { role: "user", text }]);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });
      const data = await res.json();
      const agentMsg: Message = {
        role: "agent",
        text: data.message,
        thought: data.thought,
        plan: data.plan,
        actions: data.actions,
        pendingId: data.pending_id,
        awaitingConfirm: data.needs_confirmation,
      };
      setMessages((m) => [...m, agentMsg]);
      setActiveTrace(agentMsg);
    } catch {
      setMessages((m) => [...m, { role: "agent", text: "Something went wrong reaching the backend." }]);
    } finally {
      setLoading(false);
    }
  }

  async function confirm(pendingId: string, approve: boolean) {
    if (!approve) {
      setMessages((m) => [...m, { role: "agent", text: "Cancelled — I won't run that plan." }]);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "", confirm: true, pending_id: pendingId }),
      });
      const data = await res.json();
      const agentMsg: Message = {
        role: "agent",
        text: data.message,
        thought: data.thought,
        plan: data.plan,
        actions: data.actions,
      };
      setMessages((m) => [...m, agentMsg]);
      setActiveTrace(agentMsg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="h-screen flex flex-col md:flex-row">
      {/* Chat column */}
      <div className="flex flex-col flex-1 min-w-0 border-r border-line">
        <header className="px-5 py-4 border-b border-line flex items-center justify-between shrink-0">
          <div>
            <h1 className="text-[15px] font-medium tracking-tight">AgentDesk</h1>
            <p className="text-xs text-inkDim">shows its work before it acts</p>
          </div>
          <span className="flex items-center gap-1.5 text-xs text-inkDim">
            <span className="w-1.5 h-1.5 rounded-full bg-safe" />
            live
          </span>
        </header>

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-6 space-y-5">
          {messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div
                className={
                  m.role === "user"
                    ? "max-w-[75%] bg-panelAlt rounded-lg rounded-br-sm px-4 py-2.5 text-[14px]"
                    : "max-w-[85%] space-y-2"
                }
              >
                <p className={m.role === "agent" ? "text-[14px] leading-relaxed" : ""}>{m.text}</p>

                {m.role === "agent" && (m.thought || m.plan) && (
                  <button
                    onClick={() => setActiveTrace(m)}
                    className="text-xs text-inkDim hover:text-ink underline decoration-line underline-offset-4"
                  >
                    view reasoning
                  </button>
                )}

                {m.awaitingConfirm && m.pendingId && (
                  <div className="border border-signal/40 bg-signal/5 rounded-md px-4 py-3 mt-2 space-y-2">
                    <p className="text-xs text-signal">This plan needs your go-ahead before it runs.</p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => confirm(m.pendingId!, true)}
                        className="text-xs px-3 py-1.5 rounded bg-signal text-base font-medium hover:opacity-90"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => confirm(m.pendingId!, false)}
                        className="text-xs px-3 py-1.5 rounded border border-line text-inkDim hover:text-ink"
                      >
                        Decline
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {loading && <p className="text-xs text-inkDim">thinking…</p>}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="border-t border-line p-4 flex gap-2 shrink-0"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask AgentDesk to do something…"
            className="flex-1 bg-panel border border-line rounded-md px-3 py-2 text-[14px] placeholder:text-inkDim focus:border-signal/60"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 rounded-md bg-panelAlt border border-line text-[14px] hover:border-signal/50 disabled:opacity-50"
          >
            Send
          </button>
        </form>
      </div>

      {/* Trace column */}
      <aside className="w-full md:w-[360px] shrink-0 bg-panel flex flex-col">
        <div className="px-5 py-4 border-b border-line">
          <h2 className="text-xs tracking-wide text-inkDim">agent trace</h2>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-5 font-mono text-[12.5px] leading-relaxed">
          {!activeTrace ? (
            <p className="text-inkDim">Nothing to inspect yet.</p>
          ) : (
            <div className="space-y-5">
              {activeTrace.thought && (
                <section>
                  <p className="text-inkDim mb-1">thought</p>
                  <p className="text-ink">{activeTrace.thought.thought || "—"}</p>
                </section>
              )}

              {activeTrace.thought && (
                <section className="flex gap-4">
                  <div>
                    <p className="text-inkDim mb-1">confidence</p>
                    <p>{Math.round((activeTrace.thought.confidence ?? 0) * 100)}%</p>
                  </div>
                  <div>
                    <p className="text-inkDim mb-1">risk</p>
                    <span
                      className={`inline-block px-1.5 py-0.5 rounded border text-[11px] ${
                        riskColor[activeTrace.thought.risk_level] || "text-inkDim border-line"
                      }`}
                    >
                      {activeTrace.thought.risk_level}
                    </span>
                  </div>
                </section>
              )}

              {activeTrace.thought?.uncertainty && (
                <section>
                  <p className="text-inkDim mb-1">uncertainty</p>
                  <p>{activeTrace.thought.uncertainty}</p>
                </section>
              )}

              {activeTrace.plan?.steps && activeTrace.plan.steps.length > 0 && (
                <section>
                  <p className="text-inkDim mb-2">plan</p>
                  <ol className="space-y-1.5">
                    {activeTrace.plan.steps.map((s, i) => (
                      <li key={i} className="border border-line rounded px-2.5 py-1.5">
                        <span className="text-signal">{s.action}</span>
                        {s.params && Object.keys(s.params).length > 0 && (
                          <span className="text-inkDim">
                            ({Object.entries(s.params).map(([k, v]) => `${k}=${v}`).join(", ")})
                          </span>
                        )}
                      </li>
                    ))}
                  </ol>
                </section>
              )}

              {activeTrace.actions && activeTrace.actions.length > 0 && (
                <section>
                  <p className="text-inkDim mb-2">actions</p>
                  <ul className="space-y-1.5">
                    {activeTrace.actions.map((a, i) => (
                      <li key={i} className={a.success ? "text-safe" : "text-danger"}>
                        {a.success ? "✓" : "✗"} {a.tool}
                        <p className="text-ink/80 text-[11.5px] mt-0.5">{a.result}</p>
                      </li>
                    ))}
                  </ul>
                </section>
              )}
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
