import { NextRequest, NextResponse } from "next/server";

const BACKEND_URL = process.env.BACKEND_URL || "http://localhost:8000";

export async function POST(req: NextRequest) {
  const body = await req.json();

  try {
    const res = await fetch(`${BACKEND_URL}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch (err) {
    return NextResponse.json(
      {
        type: "error",
        message:
          "Couldn't reach the AgentDesk backend. Is it running at " +
          BACKEND_URL +
          "? (uvicorn main:app --reload --port 8000)",
        needs_confirmation: false,
      },
      { status: 502 }
    );
  }
}
