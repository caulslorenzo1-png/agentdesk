import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        base: "#11141A",
        panel: "#181C24",
        panelAlt: "#1F2430",
        line: "#2A303C",
        ink: "#E9E7E0",
        inkDim: "#9AA1AE",
        signal: "#E8A33D",
        safe: "#57B88C",
        danger: "#D9695F",
      },
      fontFamily: {
        sans: ["var(--font-sans)"],
        mono: ["var(--font-mono)"],
      },
    },
  },
  plugins: [],
};

export default config;
