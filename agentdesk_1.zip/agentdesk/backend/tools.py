"""
AgentDesk Tools
Register real integrations here (Gmail, Calendar, Slack, web search, etc).
Every tool below is a stub/mock so the app runs out of the box; swap the
function bodies for real API calls when you're ready.
"""
from datetime import datetime, timedelta
from engine import Tool, ToolRegistry, ActionType, RiskLevel

# In-memory demo state (replace with real data sources)
_INBOX = [
    {"id": "1", "from": "sarah@acme.com", "subject": "Q3 numbers", "snippet": "Can you review before Friday?"},
    {"id": "2", "from": "billing@vendor.com", "subject": "Invoice #4471", "snippet": "Payment due in 10 days."},
]
_CALENDAR = [
    {"id": "1", "title": "Team standup", "start": "2026-09-11T09:00:00"},
]
_DRAFTS = []
_SENT = []


# ─── Read tools (safe, no side effects) ────────────────────────

def search_inbox(query: str = "") -> str:
    matches = [e for e in _INBOX if query.lower() in (e["subject"] + e["snippet"]).lower()] if query else _INBOX
    if not matches:
        return f"No emails found matching '{query}'."
    return "\n".join(f"[{m['id']}] {m['from']} - {m['subject']}: {m['snippet']}" for m in matches)


def get_calendar(date: str = "") -> str:
    if not _CALENDAR:
        return "No upcoming events."
    return "\n".join(f"[{e['id']}] {e['title']} at {e['start']}" for e in _CALENDAR)


def web_lookup(query: str) -> str:
    # Stub: wire this up to a real search API (Brave, Tavily, SerpAPI, etc.)
    return f"(demo) Would search the web for: '{query}'. Connect a search API in tools.py to enable this."


# ─── Draft tools (safe - creates a draft, never sends/commits) ─

def draft_email(to: str, subject: str, body: str) -> str:
    draft_id = str(len(_DRAFTS) + 1)
    _DRAFTS.append({"id": draft_id, "to": to, "subject": subject, "body": body})
    return f"Draft #{draft_id} created: to={to}, subject='{subject}'. Not sent."


def schedule_draft(title: str, start: str, duration_minutes: int = 30) -> str:
    event_id = str(len(_CALENDAR) + 100)
    return (f"Draft calendar hold prepared: '{title}' at {start} "
            f"for {duration_minutes}m (id={event_id}). Not yet confirmed on the calendar.")


# ─── Execute / irreversible tools (require confirmation) ───────

def send_email(draft_id: str) -> str:
    match = next((d for d in _DRAFTS if d["id"] == draft_id), None)
    if not match:
        return f"ERROR: No draft with id {draft_id}"
    _SENT.append(match)
    return f"Sent email to {match['to']} - subject '{match['subject']}'."


def delete_event(event_id: str) -> str:
    global _CALENDAR
    before = len(_CALENDAR)
    _CALENDAR = [e for e in _CALENDAR if e["id"] != event_id]
    if len(_CALENDAR) == before:
        return f"ERROR: No event with id {event_id}"
    return f"Deleted calendar event {event_id}."


def build_registry() -> ToolRegistry:
    registry = ToolRegistry()

    registry.register(Tool(
        name="search_inbox",
        description="Search the user's email inbox by keyword. Read-only.",
        action_type=ActionType.READ,
        risk_level=RiskLevel.LOW,
        execute=search_inbox,
    ))
    registry.register(Tool(
        name="get_calendar",
        description="List upcoming calendar events. Read-only.",
        action_type=ActionType.READ,
        risk_level=RiskLevel.LOW,
        execute=get_calendar,
    ))
    registry.register(Tool(
        name="web_lookup",
        description="Look something up on the web. Read-only.",
        action_type=ActionType.READ,
        risk_level=RiskLevel.LOW,
        execute=web_lookup,
    ))
    registry.register(Tool(
        name="draft_email",
        description="Create an email draft (to, subject, body). Does not send anything.",
        action_type=ActionType.DRAFT,
        risk_level=RiskLevel.LOW,
        execute=draft_email,
    ))
    registry.register(Tool(
        name="schedule_draft",
        description="Prepare a calendar hold (title, start ISO datetime, duration_minutes). Does not confirm it.",
        action_type=ActionType.DRAFT,
        risk_level=RiskLevel.LOW,
        execute=schedule_draft,
    ))
    registry.register(Tool(
        name="send_email",
        description="Send a previously created draft by draft_id. IRREVERSIBLE.",
        action_type=ActionType.IRREVERSIBLE,
        risk_level=RiskLevel.HIGH,
        execute=send_email,
    ))
    registry.register(Tool(
        name="delete_event",
        description="Delete a calendar event by event_id. IRREVERSIBLE.",
        action_type=ActionType.IRREVERSIBLE,
        risk_level=RiskLevel.HIGH,
        execute=delete_event,
    ))

    return registry
