"""
AgentDesk API server.

Run:
    uvicorn main:app --reload --port 8000
"""
import os
from typing import Optional, Dict, Any

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from engine import AgentEngine
from tools import build_registry

app = FastAPI(title="AgentDesk API")

allowed_origins = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

registry = build_registry()
engine = AgentEngine(registry)

# Cache of the last reasoning result per trace, so a follow-up "confirm" can
# re-run execute() without re-asking the LLM. Fine for a single-user demo;
# swap for a real session/DB store for multi-user use.
_pending: Dict[str, Dict[str, Any]] = {}


class ChatRequest(BaseModel):
    message: str
    confirm: bool = False
    pending_id: Optional[str] = None


class ChatResponse(BaseModel):
    type: str
    trace_id: Optional[str] = None
    pending_id: Optional[str] = None
    message: str
    thought: Optional[Dict[str, Any]] = None
    plan: Optional[Dict[str, Any]] = None
    actions: Optional[list] = None
    needs_confirmation: bool = False


@app.get("/health")
def health():
    return {"status": "ok", "tools": registry.list_tools()}


@app.get("/tools")
def list_tools():
    return {"tools": registry.list_tools()}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    if req.confirm and req.pending_id:
        reasoning = _pending.pop(req.pending_id, None)
        if reasoning is None:
            raise HTTPException(status_code=404, detail="Nothing pending with that id.")
        trace = engine.execute(reasoning, user_confirmed=True)
        return ChatResponse(
            type="complete",
            trace_id=trace.id,
            message=trace.final_response,
            thought=reasoning["thought"],
            plan=reasoning["plan"],
            actions=[{"tool": a.tool, "params": a.params, "result": a.result, "success": a.success}
                     for a in trace.actions],
            needs_confirmation=False,
        )

    if not req.message.strip():
        raise HTTPException(status_code=400, detail="message must not be empty")

    result = engine.process(req.message)

    if result["type"] == "confirmation_required":
        pending_id = str(len(_pending) + 1) + "-" + result["thought"]["thought"][:8]
        _pending[pending_id] = {"thought": result["thought"], "plan": result["plan"]}
        return ChatResponse(
            type="confirmation_required",
            pending_id=pending_id,
            message=result["message"],
            thought=result["thought"],
            plan=result["plan"],
            needs_confirmation=True,
        )

    return ChatResponse(
        type="complete",
        trace_id=result["trace_id"],
        message=result["message"],
        thought=result["thought"],
        plan=result["plan"],
        actions=result["actions"],
        needs_confirmation=False,
    )
