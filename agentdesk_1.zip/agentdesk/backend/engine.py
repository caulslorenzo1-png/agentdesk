"""
AgentDesk Core Engine
Reasoning -> Planning -> Execution -> Verification -> Memory
"""
import os, json, uuid
from datetime import datetime
from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass, asdict
from enum import Enum

# ─── Data Models ───────────────────────────────────────────────

class ActionType(str, Enum):
    READ = "read"
    DRAFT = "draft"
    EXECUTE = "execute"
    IRREVERSIBLE = "irreversible"

class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

@dataclass
class AgentThought:
    thought: str
    reasoning: str
    confidence: float
    risk_level: RiskLevel
    uncertainty: str

@dataclass
class AgentPlan:
    steps: List[Dict[str, Any]]
    expected_outcome: str
    needs_confirmation: bool

@dataclass
class AgentAction:
    id: str
    type: ActionType
    tool: str
    params: Dict[str, Any]
    result: Optional[str] = None
    success: bool = False
    timestamp: str = ""

@dataclass
class AgentTrace:
    id: str
    user_input: str
    thought: AgentThought
    plan: AgentPlan
    actions: List[AgentAction]
    final_response: str
    timestamp: str
    user_approved: bool = False

# ─── Configuration ─────────────────────────────────────────────

class Settings:
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    ELEVENLABS_API_KEY: str = os.getenv("ELEVENLABS_API_KEY", "")
    CONFIDENCE_THRESHOLD: float = float(os.getenv("CONFIDENCE_THRESHOLD", "0.7"))

settings = Settings()

# ─── Memory Store (in-process; swap for a DB/vector store later) ──

class MemoryStore:
    def __init__(self):
        self.short_term: List[Dict] = []
        self.long_term: List[Dict] = []
        self.episodic: List[AgentTrace] = []

    def store_turn(self, user_input: str, agent_response: str, context: Dict):
        entry = {"user": user_input, "agent": agent_response,
                  "context": context, "timestamp": datetime.now().isoformat()}
        self.short_term.append(entry)
        if len(self.short_term) > 50:
            self.short_term.pop(0)

    def store_episode(self, trace: AgentTrace):
        self.episodic.append(trace)

    def recall_relevant(self, query: str, top_k: int = 5) -> List[Dict]:
        results = []
        query_lower = query.lower()
        for trace in self.episodic[-50:]:
            score = self._similarity(query_lower, trace.user_input.lower())
            if score > 0.3:
                results.append({
                    "trace_id": trace.id,
                    "query": trace.user_input,
                    "outcome": trace.final_response,
                    "success": all(a.success for a in trace.actions) if trace.actions else True,
                    "score": score
                })
        return sorted(results, key=lambda x: x["score"], reverse=True)[:top_k]

    def store_fact(self, fact: str, category: str = "general"):
        self.long_term.append({
            "fact": fact, "category": category,
            "timestamp": datetime.now().isoformat(), "confidence": 1.0
        })

    @staticmethod
    def _similarity(a: str, b: str) -> float:
        words_a, words_b = set(a.split()), set(b.split())
        if not words_a or not words_b:
            return 0.0
        return len(words_a & words_b) / len(words_a | words_b)

memory = MemoryStore()

# ─── Tool Registry ─────────────────────────────────────────────

class Tool:
    def __init__(self, name: str, description: str,
                 action_type: ActionType, risk_level: RiskLevel,
                 execute: Callable, params_schema: Dict = None):
        self.name = name
        self.description = description
        self.action_type = action_type
        self.risk_level = risk_level
        self.execute = execute
        self.params_schema = params_schema or {}

class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def register(self, tool: Tool):
        self._tools[tool.name] = tool

    def get(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def list_tools(self) -> List[Dict[str, Any]]:
        return [{
            "name": t.name,
            "description": t.description,
            "action_type": t.action_type.value,
            "risk_level": t.risk_level.value,
        } for t in self._tools.values()]

    def tool_descriptions(self) -> str:
        lines = []
        for t in self._tools.values():
            lines.append(
                f"- {t.name}: {t.description} "
                f"[type={t.action_type.value}, risk={t.risk_level.value}]"
            )
        return "\n".join(lines)

# ─── Agent Engine ──────────────────────────────────────────────

class AgentEngine:
    def __init__(self, registry: ToolRegistry):
        self.registry = registry
        self.system_prompt = self._build_system_prompt()

    def _build_system_prompt(self) -> str:
        tools_desc = self.registry.tool_descriptions() or "(no tools registered)"
        return f"""You are AgentDesk, an autonomous AI agent. Reason before acting.

## TOOLS AVAILABLE
{tools_desc}

## REASONING PROCESS (MANDATORY)

### THOUGHT
Analyze: What does the user need? Best approach? What could go wrong?
Rate confidence 0.0-1.0.

### PLAN
Ordered list of steps, each referencing a tool with specific params.

### UNCERTAINTY
What assumptions? What info is missing?

### RISK ASSESSMENT
Rate each step low/medium/high risk.

## SAFETY RULES
1. If confidence < {settings.CONFIDENCE_THRESHOLD}, ASK before executing.
2. NEVER send emails, delete data, or purchase without explicit confirmation.
3. Draft-mode actions (draft_email, schedule_draft) are safe - execute freely.
4. Always narrate what you're about to do BEFORE doing it.
5. If a tool fails, explain and offer alternatives.
6. Learn from corrections: if the user overrides you, adapt future behavior.

## MEMORY
- Use past interactions to personalize.
- Store preferences when explicitly stated.
- Reference successful approaches for similar requests.

## OUTPUT FORMAT
Respond ONLY with valid JSON - no markdown, no preamble:
{{
  "thought": "analysis",
  "confidence": 0.85,
  "uncertainty": "what's unclear",
  "risk_level": "low",
  "plan": [
    {{"step": 1, "action": "tool_name", "params": {{"key": "value"}}, "risk": "low"}}
  ],
  "response": "natural language summary of what you'll do",
  "needs_confirmation": false
}}
"""

    def reason(self, user_input: str) -> Dict[str, Any]:
        memories = memory.recall_relevant(user_input)
        memory_context = "\n".join(
            f'- Past: "{m["query"]}" -> "{m["outcome"][:100]}"'
            for m in memories
        ) if memories else "No relevant past interactions."

        prompt = f"""{self.system_prompt}

## RELEVANT MEMORY
{memory_context}

## USER REQUEST
{user_input}

Respond ONLY with valid JSON matching the schema. No markdown."""

        raw = self._call_llm(prompt)
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            parsed = self._extract_json(raw, user_input)

        confidence = float(parsed.get("confidence", 0.5))
        risk_raw = parsed.get("risk_level", "medium")
        try:
            risk_level = RiskLevel(risk_raw)
        except ValueError:
            risk_level = RiskLevel.MEDIUM

        thought = AgentThought(
            thought=parsed.get("thought", ""),
            reasoning=parsed.get("thought", ""),
            confidence=confidence,
            risk_level=risk_level,
            uncertainty=parsed.get("uncertainty", "Unknown")
        )

        needs_confirm = (
            confidence < settings.CONFIDENCE_THRESHOLD
            or bool(parsed.get("needs_confirmation", False))
            or thought.risk_level == RiskLevel.HIGH
        )

        plan = AgentPlan(
            steps=parsed.get("plan", []),
            expected_outcome=parsed.get("response", ""),
            needs_confirmation=needs_confirm
        )

        return {
            "thought": asdict(thought),
            "plan": asdict(plan),
            "raw_response": parsed.get("response", ""),
            "needs_confirmation": needs_confirm
        }

    def execute(self, reasoning: Dict[str, Any], user_confirmed: bool = False) -> AgentTrace:
        """Runs the planned steps. `reasoning` is the full dict returned by reason()."""
        plan = reasoning["plan"]
        thought_dict = reasoning["thought"]
        trace_id = str(uuid.uuid4())
        actions: List[AgentAction] = []

        for step in plan["steps"]:
            tool_name = step.get("action", "")
            tool = self.registry.get(tool_name)

            if not tool:
                actions.append(AgentAction(
                    id=str(uuid.uuid4()), type=ActionType.READ,
                    tool=tool_name, params=step.get("params", {}),
                    result=f"ERROR: Unknown tool '{tool_name}'",
                    success=False, timestamp=datetime.now().isoformat()
                ))
                continue

            if tool.risk_level == RiskLevel.HIGH and not user_confirmed:
                actions.append(AgentAction(
                    id=str(uuid.uuid4()), type=tool.action_type,
                    tool=tool_name, params=step.get("params", {}),
                    result="BLOCKED: High-risk action requires user confirmation",
                    success=False, timestamp=datetime.now().isoformat()
                ))
                continue

            try:
                result = tool.execute(**step.get("params", {}))
                success = not str(result).startswith("ERROR")
                actions.append(AgentAction(
                    id=str(uuid.uuid4()), type=tool.action_type,
                    tool=tool_name, params=step.get("params", {}),
                    result=str(result), success=success,
                    timestamp=datetime.now().isoformat()
                ))
            except Exception as e:
                actions.append(AgentAction(
                    id=str(uuid.uuid4()), type=tool.action_type,
                    tool=tool_name, params=step.get("params", {}),
                    result=f"ERROR: {str(e)}", success=False,
                    timestamp=datetime.now().isoformat()
                ))

        results_summary = [
            f"{'OK' if a.success else 'FAIL'} {a.tool}: {a.result[:120] if a.result else ''}"
            for a in actions
        ] or [plan.get("expected_outcome", "")]

        trace = AgentTrace(
            id=trace_id,
            user_input="",
            thought=AgentThought(**thought_dict),
            plan=AgentPlan(**plan),
            actions=actions,
            final_response="\n".join(results_summary),
            timestamp=datetime.now().isoformat(),
            user_approved=user_confirmed
        )
        memory.store_episode(trace)
        return trace

    def process(self, user_input: str, user_confirmed: bool = False) -> Dict[str, Any]:
        reasoning = self.reason(user_input)

        if reasoning["needs_confirmation"] and not user_confirmed:
            return {
                "type": "confirmation_required",
                "trace_id": None,
                "thought": reasoning["thought"],
                "plan": reasoning["plan"],
                "message": reasoning["raw_response"],
                "needs_confirmation": True
            }

        trace = self.execute(reasoning, user_confirmed=user_confirmed)
        trace.user_input = user_input

        memory.store_turn(user_input, trace.final_response, {
            "trace_id": trace.id,
            "actions": len(trace.actions),
            "success_rate": (sum(1 for a in trace.actions if a.success)
                              / max(len(trace.actions), 1))
        })

        return {
            "type": "complete",
            "trace_id": trace.id,
            "thought": reasoning["thought"],
            "plan": reasoning["plan"],
            "message": trace.final_response or reasoning["raw_response"],
            "actions": [{"tool": a.tool, "params": a.params,
                         "result": a.result, "success": a.success}
                        for a in trace.actions],
            "needs_confirmation": False
        }

    # ─── LLM Calls ─────────────────────────────────────────────

    def _call_llm(self, prompt: str) -> str:
        if settings.ANTHROPIC_API_KEY:
            return self._call_anthropic(prompt)
        elif settings.OPENAI_API_KEY:
            return self._call_openai(prompt)
        return json.dumps({
            "thought": "No API key configured - running in demo mode.",
            "confidence": 0.3,
            "uncertainty": "No LLM configured",
            "risk_level": "low",
            "plan": [],
            "response": "Set ANTHROPIC_API_KEY or OPENAI_API_KEY in backend/.env to activate.",
            "needs_confirmation": False
        })

    def _call_anthropic(self, prompt: str) -> str:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
            response = client.messages.create(
                model="claude-sonnet-4-5",
                max_tokens=1024, temperature=0,
                system="Respond with valid JSON only. No markdown, no preamble.",
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text.strip()
        except ImportError:
            return json.dumps({
                "thought": "Missing dependency", "confidence": 0.0,
                "uncertainty": "pip install anthropic", "risk_level": "low",
                "plan": [], "response": "Run: pip install anthropic",
                "needs_confirmation": False
            })
        except Exception as e:
            return json.dumps({
                "thought": f"Anthropic API error: {e}", "confidence": 0.0,
                "uncertainty": "API call failed", "risk_level": "low",
                "plan": [], "response": f"LLM call failed: {e}",
                "needs_confirmation": False
            })

    def _call_openai(self, prompt: str) -> str:
        try:
            import openai
            client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
            response = client.chat.completions.create(
                model="gpt-4o",
                max_tokens=1024, temperature=0,
                messages=[
                    {"role": "system", "content": "Respond with valid JSON only. No markdown."},
                    {"role": "user", "content": prompt}
                ]
            )
            return response.choices[0].message.content.strip()
        except ImportError:
            return json.dumps({
                "thought": "Missing dependency", "confidence": 0.0,
                "uncertainty": "pip install openai", "risk_level": "low",
                "plan": [], "response": "Run: pip install openai",
                "needs_confirmation": False
            })
        except Exception as e:
            return json.dumps({
                "thought": f"OpenAI API error: {e}", "confidence": 0.0,
                "uncertainty": "API call failed", "risk_level": "low",
                "plan": [], "response": f"LLM call failed: {e}",
                "needs_confirmation": False
            })

    def _extract_json(self, raw: str, fallback_input: str) -> Dict:
        """Try to salvage JSON from a malformed LLM response."""
        try:
            start = raw.index("{")
            end = raw.rindex("}") + 1
            return json.loads(raw[start:end])
        except (ValueError, json.JSONDecodeError):
            return {
                "thought": f"Could not parse a response for: {fallback_input}",
                "confidence": 0.0,
                "uncertainty": "LLM returned non-JSON output",
                "risk_level": "low",
                "plan": [],
                "response": "I had trouble processing that - could you rephrase?",
                "needs_confirmation": False
            }
